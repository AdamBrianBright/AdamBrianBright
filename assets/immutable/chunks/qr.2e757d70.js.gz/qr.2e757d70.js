function s(n){return(n==null?void 0:n.length)!==void 0?n:Array.from(n)}const u=""+new URL("../assets/qr.42756230.png",import.meta.url).href;export{s as e,u as q};
